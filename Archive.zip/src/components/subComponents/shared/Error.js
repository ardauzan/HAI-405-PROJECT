export default function Error() {
	return <h1>Error</h1>
}
