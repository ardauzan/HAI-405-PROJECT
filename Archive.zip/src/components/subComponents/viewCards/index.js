import AttributeSelectorCard from "./AttributeSelectorCard"
import DefineNewAttributeCard from "./DefineNewAttributeCard"
export const AttributeSelectionViewCards = {
	AttributeSelectorCard,
	DefineNewAttributeCard
}

import FileSelectorCard from "./FileSelectorCard"
export const FileSelectionViewCards = {
	FileSelectorCard
}
