export default function Footer() {
	return (
		<footer>
			<ol></ol>
		</footer>
	)
}
