export default function Header() {
	return <header className="headerhome">ss</header>
}
