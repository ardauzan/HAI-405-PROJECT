import AttributeSelectionView from "./AttributeSelectionView"
import FileSelectionView from "./FileSelectionView"
export const generatorViews = {
	AttributeSelectionView,
	FileSelectionView
}
